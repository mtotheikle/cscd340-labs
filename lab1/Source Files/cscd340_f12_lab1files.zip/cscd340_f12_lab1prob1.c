#include <stdio.h>
#include <stdlib.h>

int main(int ac, char **av)
{
    int a[4];
	int *b = malloc(16);
	int *c;
	int i;

	printf("a = %p, b = %p, c = %p, i = %p\n", a, &b, &c, &i);
   printf("b = %p, c = %p\n", b, c);

    return 0;
}// end main


/*

a) Does the stack grow up or down?  How do you know? Justify your answer

b) What version of GCC are you using?

c) What is odd about how memory is arranged compared to the declarations?

d) What are the addresses for a, b, c, and i?

e) What are the contents of b and c?

f) How many bytes are allocated by the malloc?

*/