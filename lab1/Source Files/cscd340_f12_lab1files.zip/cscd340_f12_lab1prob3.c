#include <stdio.h>
#include <stdlib.h>
#include <string.h>
const int MAX=1000;

void strip(char *s)
{
  int len;
  len = strlen(s);
  if(s[len - 2] == '\r')
    s[len -2] = '\0';

  else if(s[len - 1] == '\n')
    s[len -1] = '\0';
}// end strip

void clean(int argc, char **argv)
{



}

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s\n", argv[x]);

}

int makeargs(char *s, char *** argv)
{

   return -1;

}// end makeArgs


int main()
{
  char **argv = NULL, s[] = "ls -l file";
  int argc;

  argc = makeargs(s, &argv);
  if(argc != -1)
  {
    printf("There are %d tokens.\nThe tokens are:\n", argc);
    printargs(argc, argv);

  }// end if

  clean(argc, argv);
  argv = NULL;

}// end main
